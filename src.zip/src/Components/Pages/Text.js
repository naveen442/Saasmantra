import React from 'react'
import Container from 'react-bootstrap/Container';
const Text = () => {
  return (
    <div>
      <Container>
        <h2 className='texth3'>Find The perfect plan for your Business.</h2>
      </Container>
    </div>
  )
}

export default Text;